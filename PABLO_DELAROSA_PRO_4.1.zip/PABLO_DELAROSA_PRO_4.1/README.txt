Todo el proyecto en común lo hemos hecho juntos, para mirar la parte en especifico de cada uno mirar en el PDF, aunque ha sido un trabajo bastante cooperativo en todas sus partes.
Cabe mencionar que de momento esta parte del proyecto es de José Lazo y Pablo de la Rosa, pues Claudia todavía no está al día con el proyecto.
